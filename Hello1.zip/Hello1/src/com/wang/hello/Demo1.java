package com.wang.hello;

public class Demo1 {

	public static void main(String[] args) {
	
		System.out.println("hello");
		
		System.out.println("hello1");
	}

}
